-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-12-2023 a las 02:06:38
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `asesoriacontable`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asesoria`
--

CREATE TABLE `asesoria` (
  `id` int(11) NOT NULL,
  `nombrecompleto` varchar(50) NOT NULL,
  `documento` varchar(30) NOT NULL,
  `compania` varchar(50) NOT NULL,
  `correo` varchar(20) NOT NULL,
  `celular` varchar(10) NOT NULL,
  `fecha` varchar(10) NOT NULL,
  `duracion` varchar(120) NOT NULL,
  `imagen` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `asesoria`
--

INSERT INTO `asesoria` (`id`, `nombrecompleto`, `documento`, `compania`, `correo`, `celular`, `fecha`, `duracion`, `imagen`) VALUES
(5, 'Yesileni Granados', '900814503', 'LMT ADMINISTRACIONES Y SERVICIOS CONTABLES SAS', 'delegado@lmtadminist', '3186594078', '2023-12-20', 'Servicio de asesoría contable - duración 1 hora', 'logo.png'),
(6, 'Astrid Triana ', '800134999', 'EDIFICIO DINAMARCA PH', 'dinamarca@gmail.com', '3174925235', '2023-12-23', 'Asesoría contable para propiedad horizontal - duración 2 horas', ''),
(7, 'Carlos Andrés García ', '900729905', 'ADMINISTRACIONES Y SERVICIOS LTDA ', 'admoncag@hotmail', '3174922835', '2023-12-28', 'Servicio de asesoría de revisor fiscal - duración 5 horas', ''),
(8, 'Jessica Granados', '1023939098', 'ABOGADOS ASOCIADOS SA', 'contabilidad@gmail.c', '3186594078', '2023-12-19', 'Asesoría de Normas internacionales - duracion 3 horas', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asesoria`
--
ALTER TABLE `asesoria`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asesoria`
--
ALTER TABLE `asesoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
