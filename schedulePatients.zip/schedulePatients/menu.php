<nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">LMT ADMINISTRACIONES Y SERVICIOS CONTABLES SAS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" href="<?= ROOT ?>/index.php">Inicio</a>
        <a class="nav-link" href="<?= ROOT ?>/Patients/add.php">Contactenos</a> <!-- CONTACTENOS O REGISTRO -->
        <a class="nav-link" href="<?= ROOT ?>/Patients/index.php">Ver usuarios</a>
        <a class="nav-link disabled">Cerrar sesion</a>
      </div>
    </div>
  </div>
</nav>