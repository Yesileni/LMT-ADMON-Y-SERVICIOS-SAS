<?php
include_once('functions.php'); /* Conexion del archivo de funciones */

if(!defined('ROOT')){
    define("ROOT", 'http://'.$_SERVER['HTTP_HOST'].getFolderProject());
} /* Funcion que permite guardar la URL principal de mis archivos php o html */



?>